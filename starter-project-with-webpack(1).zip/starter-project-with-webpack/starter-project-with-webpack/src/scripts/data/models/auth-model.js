import { login, register } from "../api.js";

export class AuthModel {
  async loginUser(email, password) {
    try {
      const result = await login(email, password);
      if (result.loginResult && result.loginResult.token) {
        localStorage.setItem("token", result.loginResult.token);
        localStorage.setItem("user", JSON.stringify(result.loginResult));
        return result.loginResult;
      }
      throw new Error("Invalid response");
    } catch (error) {
      throw new Error("LOGIN_FAILED");
    }
  }

  async registerUser(name, email, password) {
    try {
      const result = await register(name, email, password);
      return result;
    } catch (error) {
      throw new Error("REGISTER_FAILED");
    }
  }

  isLoggedIn() {
    return localStorage.getItem("token") !== null;
  }

  logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  }

  getCurrentUser() {
    const user = localStorage.getItem("user");
    return user ? JSON.parse(user) : null;
  }
}
