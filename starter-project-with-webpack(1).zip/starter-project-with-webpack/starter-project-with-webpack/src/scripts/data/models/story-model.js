import { getStories, addStory } from "../api.js";

export class StoryModel {
  async getAllStories() {
    try {
      const stories = await getStories();
      return stories;
    } catch (error) {
      throw new Error("STORIES_FAILED_TO_GET");
    }
  }

  async createStory(storyData) {
    try {
      const formData = new FormData();
      formData.append("description", storyData.description);
      formData.append("photo", storyData.photo);

      if (storyData.lat && storyData.lon) {
        formData.append("lat", storyData.lat);
        formData.append("lon", storyData.lon);
      }

      const result = await addStory(formData);
      return result;
    } catch (error) {
      throw new Error("STORY_FAILED_TO_CREATE");
    }
  }
}
