import { AuthModel } from "./auth-model.js"

export class UserModel {
  constructor() {
    this.authModel = new AuthModel()
  }

  async getProfile() {
    try {
      const user = this.authModel.getCurrentUser()
      if (!user) {
        throw new Error("User not logged in")
      }

      // Simulate profile data since API doesn't provide profile endpoint
      return {
        userId: user.userId,
        name: user.name,
        email: user.email || "user@example.com",
        createdAt: new Date().toISOString(), // Simulate creation date
      }
    } catch (error) {
      throw new Error("PROFILE_FAILED_TO_GET")
    }
  }

  async updateProfile(profileData) {
    try {
      // Simulate profile update since API doesn't provide update endpoint
      const currentUser = this.authModel.getCurrentUser()
      if (!currentUser) {
        throw new Error("User not logged in")
      }

      const updatedUser = {
        ...currentUser,
        ...profileData,
        updatedAt: new Date().toISOString(),
      }

      localStorage.setItem("user", JSON.stringify(updatedUser))
      return updatedUser
    } catch (error) {
      throw new Error("PROFILE_FAILED_TO_UPDATE")
    }
  }
}
