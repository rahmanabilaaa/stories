class IndexedDBHelper {
  constructor() {
    this.dbName = "DicodingStoryDB"
    this.version = 1
    this.db = null
  }

  async openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version)

      request.onerror = () => {
        console.error("IndexedDB: Error opening database")
        reject(request.error)
      }

      request.onsuccess = () => {
        this.db = request.result
        console.log("IndexedDB: Database opened successfully")
        resolve(this.db)
      }

      request.onupgradeneeded = (event) => {
        const db = event.target.result
        console.log("IndexedDB: Upgrading database")

        // Create favorites store
        if (!db.objectStoreNames.contains("favorites")) {
          const favoritesStore = db.createObjectStore("favorites", { keyPath: "id" })
          favoritesStore.createIndex("createdAt", "createdAt", { unique: false })
          console.log("IndexedDB: Favorites store created")
        }

        // Create offline stories store
        if (!db.objectStoreNames.contains("offlineStories")) {
          const offlineStore = db.createObjectStore("offlineStories", { keyPath: "id" })
          offlineStore.createIndex("createdAt", "createdAt", { unique: false })
          console.log("IndexedDB: Offline stories store created")
        }
      }
    })
  }

  async ensureDB() {
    if (!this.db) {
      await this.openDB()
    }
    return this.db
  }

  // Favorites methods
  async addToFavorites(story) {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["favorites"], "readwrite")
      const store = transaction.objectStore("favorites")

      const favoriteStory = {
        ...story,
        addedToFavoritesAt: new Date().toISOString(),
      }

      await store.add(favoriteStory)
      console.log("IndexedDB: Story added to favorites", story.id)
      return true
    } catch (error) {
      console.error("IndexedDB: Error adding to favorites", error)
      return false
    }
  }

  async removeFromFavorites(storyId) {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["favorites"], "readwrite")
      const store = transaction.objectStore("favorites")

      await store.delete(storyId)
      console.log("IndexedDB: Story removed from favorites", storyId)
      return true
    } catch (error) {
      console.error("IndexedDB: Error removing from favorites", error)
      return false
    }
  }

  async getAllFavorites() {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["favorites"], "readonly")
      const store = transaction.objectStore("favorites")

      return new Promise((resolve, reject) => {
        const request = store.getAll()
        request.onsuccess = () => {
          console.log("IndexedDB: Retrieved all favorites", request.result.length)
          resolve(request.result)
        }
        request.onerror = () => reject(request.error)
      })
    } catch (error) {
      console.error("IndexedDB: Error getting favorites", error)
      return []
    }
  }

  async isFavorite(storyId) {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["favorites"], "readonly")
      const store = transaction.objectStore("favorites")

      return new Promise((resolve, reject) => {
        const request = store.get(storyId)
        request.onsuccess = () => {
          resolve(!!request.result)
        }
        request.onerror = () => reject(request.error)
      })
    } catch (error) {
      console.error("IndexedDB: Error checking favorite status", error)
      return false
    }
  }

  // Offline stories methods
  async saveStoryOffline(story) {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["offlineStories"], "readwrite")
      const store = transaction.objectStore("offlineStories")

      const offlineStory = {
        ...story,
        savedOfflineAt: new Date().toISOString(),
      }

      await store.put(offlineStory)
      console.log("IndexedDB: Story saved offline", story.id)
      return true
    } catch (error) {
      console.error("IndexedDB: Error saving story offline", error)
      return false
    }
  }

  async getOfflineStories() {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["offlineStories"], "readonly")
      const store = transaction.objectStore("offlineStories")

      return new Promise((resolve, reject) => {
        const request = store.getAll()
        request.onsuccess = () => {
          console.log("IndexedDB: Retrieved offline stories", request.result.length)
          resolve(request.result)
        }
        request.onerror = () => reject(request.error)
      })
    } catch (error) {
      console.error("IndexedDB: Error getting offline stories", error)
      return []
    }
  }

  async clearOfflineStories() {
    try {
      const db = await this.ensureDB()
      const transaction = db.transaction(["offlineStories"], "readwrite")
      const store = transaction.objectStore("offlineStories")

      await store.clear()
      console.log("IndexedDB: Offline stories cleared")
      return true
    } catch (error) {
      console.error("IndexedDB: Error clearing offline stories", error)
      return false
    }
  }
}

export const indexedDBHelper = new IndexedDBHelper()
