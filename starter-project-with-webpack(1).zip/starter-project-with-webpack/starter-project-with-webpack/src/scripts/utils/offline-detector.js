class OfflineDetector {
  constructor() {
    this.isOnline = navigator.onLine
    this.callbacks = {
      online: [],
      offline: [],
    }
    this.init()
  }

  init() {
    window.addEventListener("online", () => {
      this.isOnline = true
      this.callbacks.online.forEach((callback) => callback())
    })

    window.addEventListener("offline", () => {
      this.isOnline = false
      this.callbacks.offline.forEach((callback) => callback())
    })
  }

  onOnline(callback) {
    this.callbacks.online.push(callback)
  }

  onOffline(callback) {
    this.callbacks.offline.push(callback)
  }

  showOfflineBanner() {
    const existingBanner = document.getElementById("offline-banner")
    if (existingBanner) return

    const banner = document.createElement("div")
    banner.id = "offline-banner"
    banner.className = "offline-banner"
    banner.innerHTML = `
      <div class="offline-content">
        <span class="offline-icon">📱</span>
        <div class="offline-text">
          <strong>Mode Offline</strong>
          <p>Beberapa fitur mungkin tidak tersedia</p>
        </div>
        <button class="offline-close" onclick="this.parentElement.parentElement.remove()">×</button>
      </div>
    `

    // Add styles
    const style = document.createElement("style")
    style.textContent = `
      .offline-banner {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
        padding: 12px 20px;
        z-index: 10001;
        box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        animation: slideDown 0.3s ease-out;
      }

      .offline-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        max-width: 1200px;
        margin: 0 auto;
      }

      .offline-content > div {
        display: flex;
        align-items: center;
        gap: 12px;
      }

      .offline-icon {
        font-size: 1.5rem;
      }

      .offline-text strong {
        display: block;
        font-weight: 600;
        font-size: 0.95rem;
      }

      .offline-text p {
        margin: 0;
        font-size: 0.8rem;
        opacity: 0.9;
      }

      .offline-close {
        background: rgba(255,255,255,0.2);
        border: none;
        color: white;
        width: 24px;
        height: 24px;
        border-radius: 50%;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
      }

      .offline-close:hover {
        background: rgba(255,255,255,0.3);
      }

      @keyframes slideDown {
        from { transform: translateY(-100%); }
        to { transform: translateY(0); }
      }

      @media (max-width: 768px) {
        .offline-content {
          flex-direction: column;
          gap: 8px;
          text-align: center;
        }
        
        .offline-close {
          position: absolute;
          top: 8px;
          right: 8px;
        }
      }
    `

    document.head.appendChild(style)
    document.body.insertBefore(banner, document.body.firstChild)

    // Auto remove after 10 seconds
    setTimeout(() => {
      if (banner.parentElement) {
        banner.remove()
      }
    }, 10000)
  }

  hideOfflineBanner() {
    const banner = document.getElementById("offline-banner")
    if (banner) {
      banner.style.animation = "slideUp 0.3s ease-out"
      setTimeout(() => banner.remove(), 300)
    }
  }
}

export const offlineDetector = new OfflineDetector()
