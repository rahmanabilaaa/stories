// Workbox Helper untuk custom functionality
class WorkboxHelper {
  constructor() {
    this.isOnline = navigator.onLine
    this.setupNetworkDetection()
    this.setupCacheManagement()
  }

  setupNetworkDetection() {
    window.addEventListener("online", () => {
      this.isOnline = true
      this.handleOnline()
    })

    window.addEventListener("offline", () => {
      this.isOnline = false
      this.handleOffline()
    })
  }

  handleOnline() {
    console.log("🌐 Back online - syncing data...")

    // Show online notification
    this.showNotification("🌐 Kembali Online", {
      body: "Koneksi internet tersedia. Data akan disinkronkan.",
      tag: "network-status",
      icon: "/icons/icon-192x192.png",
    })

    // Trigger background sync if available
    if ("serviceWorker" in navigator && "sync" in window.ServiceWorkerRegistration.prototype) {
      navigator.serviceWorker.ready
        .then((registration) => {
          return registration.sync.register("background-sync")
        })
        .catch((err) => {
          console.log("Background sync registration failed:", err)
        })
    }

    // Update UI
    this.updateNetworkStatus(true)
  }

  handleOffline() {
    console.log("📴 Gone offline - using cached data...")

    // Show offline notification
    this.showNotification("📴 Mode Offline", {
      body: "Tidak ada koneksi internet. Menggunakan data tersimpan.",
      tag: "network-status",
      icon: "/icons/icon-192x192.png",
    })

    // Update UI
    this.updateNetworkStatus(false)
  }

  updateNetworkStatus(isOnline) {
    // Remove existing status banner
    const existingBanner = document.querySelector(".network-status-banner")
    if (existingBanner) {
      existingBanner.remove()
    }

    if (!isOnline) {
      // Show offline banner
      const banner = document.createElement("div")
      banner.className = "network-status-banner offline"
      banner.innerHTML = `
        <div class="banner-content">
          <span class="banner-icon">📴</span>
          <span class="banner-text">Mode Offline - Menggunakan data tersimpan</span>
          <button class="banner-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
      `

      document.body.insertBefore(banner, document.body.firstChild)

      // Add banner styles
      if (!document.querySelector("#network-banner-styles")) {
        const styles = document.createElement("style")
        styles.id = "network-banner-styles"
        styles.textContent = `
          .network-status-banner {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 10000;
            background: #f59e0b;
            color: white;
            padding: 12px;
            text-align: center;
            font-weight: 500;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            animation: slideDown 0.3s ease;
          }
          
          .network-status-banner.offline {
            background: #ef4444;
          }
          
          .banner-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            max-width: 1200px;
            margin: 0 auto;
          }
          
          .banner-close {
            background: none;
            border: none;
            color: white;
            font-size: 20px;
            cursor: pointer;
            padding: 0 8px;
            margin-left: auto;
          }
          
          @keyframes slideDown {
            from { transform: translateY(-100%); }
            to { transform: translateY(0); }
          }
          
          @media (max-width: 768px) {
            .banner-content {
              font-size: 14px;
            }
          }
        `
        document.head.appendChild(styles)
      }
    }
  }

  setupCacheManagement() {
    // Clear old caches periodically
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.ready.then((registration) => {
        // Check for updates every 24 hours
        setInterval(
          () => {
            registration.update()
          },
          24 * 60 * 60 * 1000,
        )
      })
    }
  }

  async showNotification(title, options = {}) {
    if (!("Notification" in window)) {
      console.log("Browser tidak mendukung notifikasi")
      return
    }

    if (Notification.permission === "granted") {
      try {
        if ("serviceWorker" in navigator) {
          const registration = await navigator.serviceWorker.ready
          await registration.showNotification(title, {
            badge: "/icons/icon-72x72.png",
            icon: "/icons/icon-192x192.png",
            requireInteraction: false,
            silent: false,
            ...options,
          })
        } else {
          new Notification(title, options)
        }
      } catch (error) {
        console.error("Error showing notification:", error)
      }
    }
  }

  // Cache management utilities
  async getCacheSize() {
    if ("caches" in window) {
      const cacheNames = await caches.keys()
      let totalSize = 0

      for (const cacheName of cacheNames) {
        const cache = await caches.open(cacheName)
        const requests = await cache.keys()

        for (const request of requests) {
          const response = await cache.match(request)
          if (response) {
            const blob = await response.blob()
            totalSize += blob.size
          }
        }
      }

      return totalSize
    }
    return 0
  }

  async clearOldCaches() {
    if ("caches" in window) {
      const cacheNames = await caches.keys()
      const oldCaches = cacheNames.filter((name) => !name.includes("dicoding-story") && !name.includes("workbox"))

      await Promise.all(oldCaches.map((cacheName) => caches.delete(cacheName)))

      console.log(`Cleared ${oldCaches.length} old caches`)
    }
  }

  // Format cache size for display
  formatCacheSize(bytes) {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }
}

// Initialize Workbox Helper
const workboxHelper = new WorkboxHelper()

export default workboxHelper
