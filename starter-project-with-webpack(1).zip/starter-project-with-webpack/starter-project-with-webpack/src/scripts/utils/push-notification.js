class PushNotificationHelper {
  constructor() {
    this.isSupported = "Notification" in window
    this.hasPermission = false
    this.init()
  }

  async init() {
    if (!this.isSupported) {
      console.warn("Browser tidak mendukung notifikasi")
      return
    }

    this.hasPermission = Notification.permission === "granted"

    // Auto request permission saat aplikasi load
    if (Notification.permission === "default") {
      await this.requestPermission()
    }
  }

  async requestPermission() {
    if (!this.isSupported) return false

    try {
      const permission = await Notification.requestPermission()
      this.hasPermission = permission === "granted"

      if (this.hasPermission) {
        this.show("🔔 Notifikasi Aktif!", "Anda akan menerima pemberitahuan untuk aktivitas aplikasi")
      }

      return this.hasPermission
    } catch (error) {
      console.error("Error requesting permission:", error)
      return false
    }
  }

  show(title, body = "", options = {}) {
    console.log("Attempting to show notification:", title, body)

    // Jika tidak support, tampilkan alert sebagai fallback
    if (!this.isSupported) {
      console.warn("Notification not supported, using alert fallback")
      alert(`${title}\n${body}`)
      return false
    }

    // Jika permission belum granted, request dulu
    if (Notification.permission === "default") {
      this.requestPermission().then(() => {
        if (this.hasPermission) {
          this.show(title, body, options)
        } else {
          alert(`${title}\n${body}`)
        }
      })
      return false
    }

    // Jika permission denied, gunakan alert
    if (Notification.permission === "denied") {
      console.warn("Notification permission denied, using alert fallback")
      alert(`${title}\n${body}`)
      return false
    }

    // Jika permission granted, tampilkan notifikasi
    if (Notification.permission === "granted") {
      try {
        const notification = new Notification(title, {
          body: body,
          icon: "/icons/icon-192x192.png",
          badge: "/icons/icon-72x72.png",
          tag: options.tag || "app-notification",
          requireInteraction: false,
          silent: false,
          ...options,
        })

        // Auto close setelah 5 detik
        setTimeout(() => {
          notification.close()
        }, 5000)

        // Event listeners
        notification.onclick = () => {
          window.focus()
          notification.close()
        }

        console.log("Notification shown successfully")
        return true
      } catch (error) {
        console.error("Error showing notification:", error)
        // Fallback ke alert
        alert(`${title}\n${body}`)
        return false
      }
    }

    return false
  }

  // Method khusus untuk berbagai jenis notifikasi
  showStoryCreated(description) {
    this.show(
      "🎉 Cerita Berhasil Dibuat!",
      `"${description.substring(0, 50)}${description.length > 50 ? "..." : ""}" telah ditambahkan`,
      { tag: "story-created" },
    )
  }

  showFavoriteAdded(description) {
    this.show(
      "❤️ Ditambah ke Favorit",
      `"${description.substring(0, 50)}${description.length > 50 ? "..." : ""}" telah ditambahkan ke favorit`,
      { tag: "favorite-added" },
    )
  }

  showFavoriteRemoved(description) {
    this.show(
      "🗑️ Dihapus dari Favorit",
      `"${description.substring(0, 50)}${description.length > 50 ? "..." : ""}" telah dihapus dari favorit`,
      { tag: "favorite-removed" },
    )
  }

  showLogin(userName) {
    this.show("👋 Selamat Datang!", `Halo ${userName}, Anda berhasil login`, { tag: "login-success" })
  }

  showLogout() {
    this.show("👋 Sampai Jumpa!", "Anda telah berhasil logout", { tag: "logout-success" })
  }

  showRegister(userName) {
    this.show("🎉 Registrasi Berhasil!", `Selamat datang ${userName}! Akun Anda telah dibuat`, {
      tag: "register-success",
    })
  }

  showOnline() {
    this.show("🟢 Kembali Online", "Koneksi internet telah pulih", { tag: "connection-online" })
  }

  showOffline() {
    this.show("📱 Mode Offline", "Anda sedang offline. Beberapa fitur mungkin tidak tersedia", {
      tag: "connection-offline",
    })
  }

  showError(message) {
    this.show("❌ Terjadi Kesalahan", message, { tag: "error" })
  }

  // Untuk kompatibilitas dengan kode lama
  showLocalNotification(title, options = {}) {
    return this.show(title, options.body || "", options)
  }

  isEnabled() {
    return this.isSupported && this.hasPermission
  }

  isTypeEnabled(type) {
    return this.isEnabled()
  }
}

export const pushNotificationHelper = new PushNotificationHelper()
