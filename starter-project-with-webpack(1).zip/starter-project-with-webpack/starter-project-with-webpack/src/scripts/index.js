import "../styles/styles.css"
import App from "./pages/app.js"
import { indexedDBHelper } from "./utils/indexeddb.js"
import { pushNotificationHelper } from "./utils/push-notification.js"

document.addEventListener("DOMContentLoaded", async () => {
  console.log("App starting...")

  // Initialize IndexedDB
  try {
    await indexedDBHelper.openDB()
    console.log("IndexedDB initialized successfully")
  } catch (error) {
    console.error("Failed to initialize IndexedDB:", error)
  }

  // Initialize notification helper - PENTING!
  console.log("Initializing notifications...")
  try {
    await pushNotificationHelper.requestPermission()
    console.log("Notification permission:", Notification.permission)
  } catch (error) {
    console.error("Error initializing notifications:", error)
  }

  const app = new App({
    content: document.querySelector("#main-content"),
    drawerButton: document.querySelector("#drawer-button"),
    navigationDrawer: document.querySelector("#navigation-drawer"),
  })

  await app.renderPage()

  window.addEventListener("hashchange", async () => {
    await app.renderPage()
  })

  window.addEventListener("popstate", async () => {
    await app.renderPage()
  })

  const drawerButton = document.querySelector("#drawer-button")
  const navigationDrawer = document.querySelector("#navigation-drawer")

  if (drawerButton && navigationDrawer) {
    const updateAriaExpanded = () => {
      const isOpen = navigationDrawer.classList.contains("open")
      drawerButton.setAttribute("aria-expanded", isOpen.toString())
    }

    const observer = new MutationObserver(updateAriaExpanded)
    observer.observe(navigationDrawer, {
      attributes: true,
      attributeFilter: ["class"],
    })
  }

  const skipLink = document.querySelector(".skip-link")
  const mainContent = document.querySelector("#main-content")

  if (skipLink && mainContent) {
    skipLink.addEventListener("click", (event) => {
      event.preventDefault()
      skipLink.blur()
      mainContent.setAttribute("tabindex", "-1")
      mainContent.focus()
      mainContent.scrollIntoView()
    })
  }

  // Register Service Worker
  if ("serviceWorker" in navigator) {
    try {
      const registration = await navigator.serviceWorker.register("/sw-enhanced.js")
      console.log("Service Worker registered successfully:", registration)

      // Listen for updates
      registration.addEventListener("updatefound", () => {
        const newWorker = registration.installing
        newWorker.addEventListener("statechange", () => {
          if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
            // New content is available, refresh the page
            if (confirm("Aplikasi telah diperbarui. Refresh untuk mendapatkan versi terbaru?")) {
              window.location.reload()
            }
          }
        })
      })
    } catch (error) {
      console.log("Service Worker registration failed:", error)
    }
  }

  // Handle online/offline events with notifications
  window.addEventListener("online", () => {
    console.log("Back online")
    pushNotificationHelper.showOnline()
  })

  window.addEventListener("offline", () => {
    console.log("Gone offline")
    pushNotificationHelper.showOffline()
  })

  // Handle app installation
  let deferredPrompt
  window.addEventListener("beforeinstallprompt", (e) => {
    console.log("beforeinstallprompt fired")
    e.preventDefault()
    deferredPrompt = e

    // Show install button or banner
    showInstallPromotion()
  })

  function showInstallPromotion() {
    // Create install banner
    const installBanner = document.createElement("div")
    installBanner.innerHTML = `
      <div style="position: fixed; bottom: 20px; left: 20px; right: 20px; background: var(--primary-color); color: white; padding: 16px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); z-index: 10000; display: flex; align-items: center; justify-content: space-between;">
        <div>
          <strong>Install Berbagi Cerita</strong>
          <p style="margin: 4px 0 0 0; font-size: 14px;">Akses lebih cepat dari homescreen</p>
        </div>
        <div>
          <button id="install-btn" style="background: white; color: var(--primary-color); border: none; padding: 8px 16px; border-radius: 4px; font-weight: 600; margin-right: 8px;">Install</button>
          <button id="dismiss-btn" style="background: transparent; color: white; border: 1px solid white; padding: 8px 16px; border-radius: 4px;">Nanti</button>
        </div>
      </div>
    `

    document.body.appendChild(installBanner)

    document.getElementById("install-btn").addEventListener("click", async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt()
        const { outcome } = await deferredPrompt.userChoice
        console.log(`User response to the install prompt: ${outcome}`)
        deferredPrompt = null
        document.body.removeChild(installBanner)
      }
    })

    document.getElementById("dismiss-btn").addEventListener("click", () => {
      document.body.removeChild(installBanner)
    })
  }

  window.addEventListener("appinstalled", (evt) => {
    console.log("App was installed")
    // Show thank you message
    pushNotificationHelper.show("Terima Kasih!", "Berbagi Cerita telah berhasil diinstall")
  })
})

// Global error handling
window.addEventListener("error", (event) => {
  console.error("Global error:", event.error)
})

window.addEventListener("unhandledrejection", (event) => {
  console.error("Unhandled promise rejection:", event.reason)
})
