export class LoginPresenter {
  constructor(model, view) {
    this.model = model
    this.view = view
  }

  async login() {
    try {
      this.view.showLoading()
      const loginData = this.view.getFormData()

      if (!loginData.email || !loginData.password) {
        throw new Error("Email dan password harus diisi")
      }

      if (!this.isValidEmail(loginData.email)) {
        throw new Error("Format email tidak valid")
      }

      console.log("Attempting login...")
      const result = await this.model.login(loginData)

      console.log("Login successful:", result)
      this.view.showLoginSuccess(result.loginResult)
    } catch (error) {
      console.error("Login error:", error)
      this.view.showLoginError(error.message)
    }
  }

  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }
}
