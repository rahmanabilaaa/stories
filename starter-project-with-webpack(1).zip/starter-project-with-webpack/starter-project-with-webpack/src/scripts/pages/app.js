import routes from "../routes/routes.js"
import { getActiveRoute } from "../routes/url-parser.js"
import { AuthModel } from "../data/models/auth-model.js"

class App {
  #content = null
  #drawerButton = null
  #navigationDrawer = null
  #authModel = null

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content
    this.#drawerButton = drawerButton
    this.#navigationDrawer = navigationDrawer
    this.#authModel = new AuthModel()

    this.#setupDrawer()
    this.#updateNavigation()
    this.#setupErrorHandling()
  }

  #setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open")
      const isOpen = this.#navigationDrawer.classList.contains("open")
      this.#drawerButton.setAttribute("aria-expanded", isOpen)
    })

    document.body.addEventListener("click", (event) => {
      if (!this.#navigationDrawer.contains(event.target) && !this.#drawerButton.contains(event.target)) {
        this.#navigationDrawer.classList.remove("open")
        this.#drawerButton.setAttribute("aria-expanded", "false")
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open")
          this.#drawerButton.setAttribute("aria-expanded", "false")
        }
      })
    })
  }

  #setupErrorHandling() {
    // Handle route errors
    window.addEventListener("error", (event) => {
      console.error("Global error:", event.error)
      this.#handleRouteError()
    })

    // Handle unhandled promise rejections
    window.addEventListener("unhandledrejection", (event) => {
      console.error("Unhandled promise rejection:", event.reason)
      this.#handleRouteError()
    })
  }

  #handleRouteError() {
    // Redirect to not found page on critical errors
    if (!window.location.hash.includes("not-found")) {
      window.location.hash = "#/not-found"
    }
  }

  #updateNavigation() {
    const navList = document.getElementById("nav-list")
    const isLoggedIn = this.#authModel.isLoggedIn()

    if (isLoggedIn) {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/add-story">Tambah Cerita</a></li>
        <li><a href="#/favorites">Favorit</a></li>
        <li><a href="#" id="logout-link">Logout</a></li>
      `
      document.getElementById("logout-link").addEventListener("click", (e) => {
        e.preventDefault()
        if (confirm("Yakin ingin logout?")) {
          this.#authModel.logout()
          window.location.hash = "#/"
          this.#updateNavigation()
        }
      })
    } else {
      navList.innerHTML = `
        <li><a href="#/">Beranda</a></li>
        <li><a href="#/login">Masuk</a></li>
        <li><a href="#/register">Daftar</a></li>
      `
    }

    // Update active navigation
    this.#updateActiveNavigation()
  }

  #updateActiveNavigation() {
    const currentHash = window.location.hash
    const navLinks = document.querySelectorAll("#nav-list a")

    navLinks.forEach((link) => {
      link.classList.remove("active")
      if (link.getAttribute("href") === currentHash) {
        link.classList.add("active")
      }
    })
  }

  async renderPage() {
    try {
      const url = getActiveRoute()
      const page = routes[url]

      // Handle unknown routes - redirect to not found
      if (!page) {
        console.warn(`Route not found: ${url}`)
        window.location.hash = "#/not-found"
        return
      }

      // Use View Transition API if available
      if ("startViewTransition" in document) {
        document.startViewTransition(async () => {
          await this.#renderPageContent(page)
        })
      } else {
        await this.#renderPageContent(page)
      }

      this.#updateNavigation()
    } catch (error) {
      console.error("Error rendering page:", error)
      this.#handleRouteError()
    }
  }

  async #renderPageContent(page) {
    try {
      // Show loading state
      this.#content.innerHTML = `
        <div class="loading">
          <div class="spinner"></div>
          <p>Memuat halaman...</p>
        </div>
      `

      // Render page
      this.#content.innerHTML = await page.render()
      await page.afterRender()

      // Scroll to top
      window.scrollTo({ top: 0, behavior: "smooth" })
    } catch (error) {
      console.error("Error rendering page content:", error)

      // Show error page
      this.#content.innerHTML = `
        <section class="container">
          <div class="error-page">
            <h1>⚠️ Terjadi Kesalahan</h1>
            <p>Maaf, terjadi kesalahan saat memuat halaman.</p>
            <div class="error-actions">
              <button onclick="window.location.reload()" class="btn btn-primary">
                Muat Ulang Halaman
              </button>
              <a href="#/" class="btn btn-secondary">Kembali ke Beranda</a>
            </div>
          </div>
        </section>
      `
    }
  }
}

export default App

// Enhanced cleanup when page changes
window.addEventListener("hashchange", () => {
  // Stop any running media streams
  const video = document.querySelector("video")
  if (video && video.srcObject) {
    video.srcObject.getTracks().forEach((track) => track.stop())
    video.srcObject = null
  }

  // Clear any running intervals/timeouts
  const highestTimeoutId = setTimeout(() => {}, 0)
  for (let i = 0; i < highestTimeoutId; i++) {
    clearTimeout(i)
  }

  // Remove any temporary event listeners
  document.querySelectorAll("[data-temp-listener]").forEach((el) => {
    el.remove()
  })
})
