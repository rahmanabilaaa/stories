import { StoryModel } from "../../data/models/story-model.js"
import { AuthModel } from "../../data/models/auth-model.js"
import { HomePagePresenter } from "./home-presenter.js"
import { showFormattedDate } from "../../utils/index.js"
import { indexedDBHelper } from "../../utils/indexeddb.js"
import { pushNotificationHelper } from "../../utils/push-notification.js"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

export default class HomePage {
  constructor() {
    this.authModel = new AuthModel()
    this.customIcon = null
    this.map = null
  }

  createCustomIcon() {
    if (!this.customIcon) {
      this.customIcon = L.divIcon({
        className: "custom-story-marker",
        html: `
          <div class="marker-pin">
            <div class="marker-icon">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="#e74c3c"/>
              </svg>
            </div>
          </div>
        `,
        iconSize: [30, 40],
        iconAnchor: [15, 40],
        popupAnchor: [0, -40],
      })
    }
    return this.customIcon
  }

  async render() {
    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <header class="page-header">
          <h1>Berbagi Cerita</h1>
          <p>Bagikan momen berharga Anda</p>
          <div class="page-actions">
            ${
              this.authModel.isLoggedIn()
                ? `
                <a href="#/add-story" class="btn btn-primary">
                  <span>📝</span> Tambah Cerita Baru
                </a>
                <button id="test-notification-btn" class="btn btn-outline">
                  <span>🔔</span> Test Notifikasi
                </button>
                <button id="notification-settings-btn" class="btn btn-outline">
                  <span>🔔</span> Pengaturan Notifikasi
                </button>
                `
                : '<a href="#/login" class="btn btn-primary">Login untuk Berbagi</a>'
            }
          </div>
        </header>

        <!-- Notification Settings Modal -->
        <div id="notification-modal" class="modal hidden">
          <div class="modal-content">
            <div class="modal-header">
              <h3>Pengaturan Notifikasi</h3>
              <button id="close-modal" class="close-btn">&times;</button>
            </div>
            <div class="modal-body">
              <div class="setting-item">
                <label class="toggle-container">
                  <input type="checkbox" id="story-notifications-toggle">
                  <span class="toggle-slider"></span>
                  <span class="toggle-label">Notifikasi Cerita</span>
                </label>
                <p class="setting-description">Notifikasi saat menambah cerita baru</p>
              </div>
              <div class="setting-item">
                <label class="toggle-container">
                  <input type="checkbox" id="favorite-notifications-toggle">
                  <span class="toggle-slider"></span>
                  <span class="toggle-label">Notifikasi Favorit</span>
                </label>
                <p class="setting-description">Notifikasi saat menambah atau menghapus favorit</p>
              </div>
            </div>
            <div class="modal-footer">
              <button id="save-settings" class="btn btn-primary">Simpan Pengaturan</button>
            </div>
          </div>
        </div>

        <div id="loading-container" class="loading hidden">
          <div class="spinner"></div>
          <p>Memuat cerita...</p>
        </div>

        <div id="error-container" class="error-message hidden">
          <p>Gagal memuat cerita. Silakan coba lagi.</p>
          <button id="retry-button" class="btn btn-secondary">Coba Lagi</button>
        </div>

        <div id="stories-container" class="stories-grid">
          <!-- Stories will be rendered here -->
        </div>

        <div id="map-section" class="map-section">
          <h2>Peta Lokasi Cerita</h2>
          <p>Klik marker untuk melihat detail cerita dengan gambar</p>
          <div id="home-map" class="map"></div>
        </div>
      </section>

      <style>
        .page-actions {
          display: flex;
          gap: var(--spacing-md);
          justify-content: center;
          flex-wrap: wrap;
          margin-top: var(--spacing-lg);
        }

        .stories-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: var(--spacing-xl);
          margin: var(--spacing-2xl) 0;
        }
        
        .story-card {
          border-radius: var(--radius-lg);
          overflow: hidden;
          box-shadow: var(--shadow);
          background: var(--surface-color);
          position: relative;
          transition: all 0.3s ease;
          border: 1px solid var(--border-color);
        }

        .story-card:hover {
          transform: translateY(-4px);
          box-shadow: var(--shadow-xl);
        }
        
        .story-image {
          width: 100%;
          height: 240px;
          overflow: hidden;
          position: relative;
        }
        
        .story-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s ease;
        }

        .story-card:hover .story-image img {
          transform: scale(1.05);
        }
        
        .story-content {
          padding: var(--spacing-xl);
        }
        
        .story-title {
          font-size: 1.25rem;
          font-weight: 700;
          margin: 0 0 var(--spacing-sm) 0;
          color: var(--text-primary);
        }
        
        .story-description {
          margin-bottom: var(--spacing-lg);
          color: var(--text-secondary);
          line-height: 1.6;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        
        .story-meta {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 0.875rem;
          color: var(--text-muted);
          margin-bottom: var(--spacing-sm);
        }

        .favorite-actions {
          position: absolute;
          top: 12px;
          right: 12px;
          display: flex;
          gap: 8px;
          z-index: 10;
        }

        .favorite-btn {
          background: rgba(255, 255, 255, 0.95);
          border: 2px solid transparent;
          border-radius: 50%;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 2px 12px rgba(0,0,0,0.15);
          font-size: 20px;
          backdrop-filter: blur(8px);
        }

        .favorite-btn:hover {
          background: white;
          transform: scale(1.1);
          box-shadow: 0 4px 20px rgba(0,0,0,0.25);
        }

        .favorite-btn.active {
          background: #ef4444;
          color: white;
          border-color: #dc2626;
          animation: heartBeat 0.6s ease-in-out;
        }

        .favorite-btn.active:hover {
          background: #dc2626;
        }

        @keyframes heartBeat {
          0% { transform: scale(1); }
          25% { transform: scale(1.2); }
          50% { transform: scale(1.1); }
          75% { transform: scale(1.15); }
          100% { transform: scale(1.1); }
        }

        .favorite-count {
          position: absolute;
          bottom: 12px;
          right: 12px;
          background: rgba(239, 68, 68, 0.9);
          color: white;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 12px;
          font-weight: 600;
          backdrop-filter: blur(4px);
        }
        
        .custom-story-marker {
          background: transparent;
          border: none;
        }
        
        .marker-pin {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }
        
        .marker-icon {
          background: white;
          border-radius: 50%;
          padding: 6px;
          box-shadow: 0 3px 12px rgba(0,0,0,0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid #e74c3c;
        }
        
        .custom-story-marker:hover .marker-icon {
          transform: scale(1.15);
          transition: transform 0.2s ease;
          box-shadow: 0 4px 20px rgba(231, 76, 60, 0.4);
        }

        /* Modal Styles */
        .modal {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0, 0, 0, 0.6);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10000;
          backdrop-filter: blur(4px);
        }

        .modal.hidden {
          display: none;
        }

        .modal-content {
          background: var(--surface-color);
          border-radius: var(--radius-xl);
          box-shadow: var(--shadow-xl);
          width: 90%;
          max-width: 500px;
          max-height: 80vh;
          overflow-y: auto;
        }

        .modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: var(--spacing-xl);
          border-bottom: 1px solid var(--border-color);
        }

        .modal-header h3 {
          margin: 0;
          font-size: 1.5rem;
          font-weight: 700;
          color: var(--text-primary);
        }

        .close-btn {
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          color: var(--text-muted);
          padding: 4px;
          border-radius: 4px;
          transition: all 0.2s;
        }

        .close-btn:hover {
          background: var(--surface-hover);
          color: var(--text-primary);
        }

        .modal-body {
          padding: var(--spacing-xl);
        }

        .setting-item {
          margin-bottom: var(--spacing-xl);
          padding-bottom: var(--spacing-lg);
          border-bottom: 1px solid var(--border-color);
        }

        .setting-item:last-child {
          border-bottom: none;
          margin-bottom: 0;
        }

        .toggle-container {
          display: flex;
          align-items: center;
          gap: var(--spacing-md);
          cursor: pointer;
          margin-bottom: var(--spacing-sm);
        }

        .toggle-slider {
          position: relative;
          width: 50px;
          height: 24px;
          background: var(--border-color);
          border-radius: 24px;
          transition: all 0.3s;
        }

        .toggle-slider::before {
          content: '';
          position: absolute;
          top: 2px;
          left: 2px;
          width: 20px;
          height: 20px;
          background: white;
          border-radius: 50%;
          transition: all 0.3s;
          box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .toggle-container input:checked + .toggle-slider {
          background: var(--primary-color);
        }

        .toggle-container input:checked + .toggle-slider::before {
          transform: translateX(26px);
        }

        .toggle-container input {
          display: none;
        }

        .toggle-label {
          font-weight: 600;
          color: var(--text-primary);
        }

        .setting-description {
          color: var(--text-secondary);
          font-size: 0.875rem;
          margin: 0;
          line-height: 1.5;
        }

        .modal-footer {
          padding: var(--spacing-xl);
          border-top: 1px solid var(--border-color);
          text-align: right;
        }

        /* Enhanced Map Popup Styles */
        .leaflet-popup-content-wrapper {
          border-radius: var(--radius-lg) !important;
          box-shadow: var(--shadow-xl) !important;
          border: 1px solid var(--border-color) !important;
        }

        .leaflet-popup-content {
          margin: 0 !important;
          font-family: inherit !important;
          line-height: 1.5 !important;
        }

        .map-popup-content {
          min-width: 250px;
          max-width: 300px;
        }

        .map-popup-image {
          width: 100%;
          height: 150px;
          object-fit: cover;
          border-radius: var(--radius) var(--radius) 0 0;
          margin-bottom: var(--spacing-sm);
        }

        .map-popup-body {
          padding: var(--spacing-md);
        }

        .map-popup-title {
          font-size: 1rem;
          font-weight: 700;
          margin: 0 0 var(--spacing-sm) 0;
          color: var(--primary-color);
        }

        .map-popup-description {
          font-size: 0.875rem;
          color: var(--text-secondary);
          margin: 0 0 var(--spacing-sm) 0;
          line-height: 1.4;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .map-popup-meta {
          font-size: 0.75rem;
          color: var(--text-muted);
          margin: 0;
          padding-top: var(--spacing-sm);
          border-top: 1px solid var(--border-color);
        }

        @media (max-width: 768px) {
          .page-actions {
            flex-direction: column;
            align-items: center;
          }

          .stories-grid {
            grid-template-columns: 1fr;
            gap: var(--spacing-lg);
          }

          .modal-content {
            width: 95%;
            margin: var(--spacing-md);
          }

          .map-popup-content {
            min-width: 200px;
            max-width: 250px;
          }
        }

        .offline-banner {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          background: linear-gradient(135deg, #f59e0b, #d97706);
          color: white;
          padding: 12px;
          text-align: center;
          z-index: 10001;
          box-shadow: 0 2px 8px rgba(0,0,0,0.2);
          animation: slideDown 0.3s ease-out;
        }

        .offline-content {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: var(--spacing-sm);
        }

        .offline-content span {
          font-weight: 600;
        }

        .offline-content p {
          margin: 0;
          font-size: 0.875rem;
          opacity: 0.9;
        }

        @keyframes slideDown {
          from { transform: translateY(-100%); }
          to { transform: translateY(0); }
        }

        @media (max-width: 768px) {
          .offline-content {
            flex-direction: column;
            gap: 4px;
          }
        }
      </style>
    `
  }

  async afterRender() {
    if (!this.authModel.isLoggedIn()) {
      this.renderLoginPrompt()
      return
    }

    const model = new StoryModel()
    const presenter = new HomePagePresenter(model, this)

    // Setup event listeners
    this.setupEventListeners()

    const retryButton = document.getElementById("retry-button")
    if (retryButton) {
      retryButton.addEventListener("click", () => {
        presenter.loadStories()
      })
    }

    await presenter.loadStories()

    // Add offline detection
    this.setupOfflineDetection()
  }

  setupEventListeners() {
    // Notification settings modal
    const notificationBtn = document.getElementById("notification-settings-btn")
    const modal = document.getElementById("notification-modal")
    const closeBtn = document.getElementById("close-modal")
    const saveBtn = document.getElementById("save-settings")

    if (notificationBtn) {
      notificationBtn.addEventListener("click", () => {
        this.openNotificationSettings()
      })
    }

    if (closeBtn) {
      closeBtn.addEventListener("click", () => {
        modal.classList.add("hidden")
      })
    }

    if (saveBtn) {
      saveBtn.addEventListener("click", () => {
        this.saveNotificationSettings()
      })
    }

    // Close modal when clicking outside
    if (modal) {
      modal.addEventListener("click", (e) => {
        if (e.target === modal) {
          modal.classList.add("hidden")
        }
      })
    }

    // Test notification button
    const testNotificationBtn = document.getElementById("test-notification-btn")
    if (testNotificationBtn) {
      testNotificationBtn.addEventListener("click", () => {
        console.log("Testing notification...")

        // Test dengan berbagai cara
        pushNotificationHelper.show("🧪 Test Notifikasi", "Ini adalah test notifikasi untuk memastikan sistem bekerja")

        // Juga tampilkan alert sebagai backup
        setTimeout(() => {
          alert("🧪 Test Notifikasi\nIni adalah test notifikasi untuk memastikan sistem bekerja")
        }, 1000)
      })
    }
  }

  openNotificationSettings() {
    const modal = document.getElementById("notification-modal")

    // Load current settings
    const settings = pushNotificationHelper.getSettings()
    document.getElementById("story-notifications-toggle").checked = settings.storyNotifications
    document.getElementById("favorite-notifications-toggle").checked = settings.favoriteNotifications

    modal.classList.remove("hidden")
  }

  saveNotificationSettings() {
    const settings = {
      storyNotifications: document.getElementById("story-notifications-toggle").checked,
      favoriteNotifications: document.getElementById("favorite-notifications-toggle").checked,
    }

    localStorage.setItem("notificationSettings", JSON.stringify(settings))
    document.getElementById("notification-modal").classList.add("hidden")

    // Show confirmation
    pushNotificationHelper.showNotification("⚙️ Pengaturan Tersimpan", {
      body: "Pengaturan notifikasi telah berhasil disimpan",
    })
  }

  renderLoginPrompt() {
    const container = document.getElementById("stories-container")
    container.innerHTML = `
      <div class="login-prompt">
        <h2>Selamat Datang!</h2>
        <p>Silakan login untuk melihat dan berbagi cerita menarik.</p>
        <a href="#/login" class="btn btn-primary">Login Sekarang</a>
      </div>
    `
  }

  showLoading() {
    document.getElementById("loading-container").classList.remove("hidden")
    document.getElementById("error-container").classList.add("hidden")
    document.getElementById("stories-container").innerHTML = ""
  }

  hideLoading() {
    document.getElementById("loading-container").classList.add("hidden")
  }

  async renderStories(stories) {
    this.hideLoading()
    const container = document.getElementById("stories-container")

    if (stories.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <h2>Belum Ada Cerita</h2>
          <p>Jadilah yang pertama berbagi cerita!</p>
          <a href="#/add-story" class="btn btn-primary">Tambah Cerita</a>
        </div>
      `
      return
    }

    // Check favorite status for each story
    const storiesWithFavoriteStatus = await Promise.all(
      stories.map(async (story) => ({
        ...story,
        isFavorite: await indexedDBHelper.isFavorite(story.id),
      })),
    )

    // Get favorite count
    const favoriteCount = storiesWithFavoriteStatus.filter((story) => story.isFavorite).length

    const storiesHTML = storiesWithFavoriteStatus
      .map(
        (story) => `
      <article class="story-card">
        ${
          this.authModel.isLoggedIn()
            ? `
        <div class="favorite-actions">
          <button class="favorite-btn ${story.isFavorite ? "active" : ""}" 
                  onclick="window.toggleFavorite('${story.id}')" 
                  aria-label="${story.isFavorite ? "Hapus dari favorit" : "Tambah ke favorit"}"
                  title="${story.isFavorite ? "Hapus dari favorit" : "Tambah ke favorit"}">
            ${story.isFavorite ? "❤️" : "🤍"}
          </button>
        </div>
        `
            : ""
        }
        <div class="story-image">
          <img src="${story.photoUrl}" alt="Foto cerita: ${story.description}" loading="lazy">
        </div>
        <div class="story-content">
          <h3 class="story-title">${story.name}</h3>
          <p class="story-description">${story.description}</p>
          <div class="story-meta">
            <time datetime="${story.createdAt}">
              📅 ${showFormattedDate(story.createdAt, "id-ID")}
            </time>
            ${story.lat && story.lon ? `<span class="location">📍 Ada lokasi</span>` : ""}
          </div>
        </div>
      </article>
    `,
      )
      .join("")

    container.innerHTML = storiesHTML

    // Show favorite count if user is logged in
    if (this.authModel.isLoggedIn() && favoriteCount > 0) {
      const header = document.querySelector(".page-header")
      const existingCount = header.querySelector(".favorite-count")
      if (existingCount) existingCount.remove()

      const countElement = document.createElement("div")
      countElement.className = "favorite-count"
      countElement.innerHTML = `❤️ ${favoriteCount} cerita favorit`
      header.appendChild(countElement)
    }

    // Setup global toggle favorite function
    window.toggleFavorite = async (storyId) => {
      const story = stories.find((s) => s.id === storyId)
      if (!story) return

      console.log("Toggling favorite for story:", storyId)
      const isFavorite = await indexedDBHelper.isFavorite(storyId)

      if (isFavorite) {
        const success = await indexedDBHelper.removeFromFavorites(storyId)
        if (success) {
          console.log("Removed from favorites, showing notification...")

          // Update UI
          const btn = document.querySelector(`button[onclick="window.toggleFavorite('${storyId}')"]`)
          if (btn) {
            btn.classList.remove("active")
            btn.innerHTML = "🤍"
            btn.setAttribute("aria-label", "Tambah ke favorit")
            btn.setAttribute("title", "Tambah ke favorit")
          }

          // Show notification - PASTI DIPANGGIL
          pushNotificationHelper.showFavoriteRemoved(story.description)

          // Juga tampilkan alert sebagai backup
          alert("🗑️ Dihapus dari favorit!")
        }
      } else {
        const success = await indexedDBHelper.addToFavorites(story)
        if (success) {
          console.log("Added to favorites, showing notification...")

          // Update UI
          const btn = document.querySelector(`button[onclick="window.toggleFavorite('${storyId}')"]`)
          if (btn) {
            btn.classList.add("active")
            btn.innerHTML = "❤️"
            btn.setAttribute("aria-label", "Hapus dari favorit")
            btn.setAttribute("title", "Hapus dari favorit")
          }

          // Show notification - PASTI DIPANGGIL
          pushNotificationHelper.showFavoriteAdded(story.description)

          // Juga tampilkan alert sebagai backup
          alert("❤️ Ditambah ke favorit!")
        }
      }
    }

    this.renderMapWithMarkers(stories)
  }

  updateFavoriteCount(change) {
    const header = document.querySelector(".page-header")
    let countElement = header.querySelector(".favorite-count")

    if (!countElement) {
      countElement = document.createElement("div")
      countElement.className = "favorite-count"
      header.appendChild(countElement)
    }

    const currentCount = Number.parseInt(countElement.textContent.match(/\d+/)?.[0] || "0")
    const newCount = Math.max(0, currentCount + change)

    if (newCount > 0) {
      countElement.innerHTML = `❤️ ${newCount} cerita favorit`
      countElement.style.display = "block"
    } else {
      countElement.style.display = "none"
    }
  }

  renderMapWithMarkers(stories) {
    const mapContainer = document.getElementById("home-map")

    if (!mapContainer) {
      console.error("Map container not found")
      return
    }

    if (this.map) {
      this.map.remove()
      this.map = null
    }

    try {
      if (mapContainer.offsetWidth === 0 || mapContainer.offsetHeight === 0) {
        mapContainer.style.height = "500px"
        mapContainer.style.width = "100%"
      }

      this.map = L.map(mapContainer, {
        center: [-2.5, 117.5],
        zoom: 5,
      })

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 18,
      }).addTo(this.map)

      const customIcon = this.createCustomIcon()
      const storyLocations = stories.filter((story) => story.lat && story.lon)

      storyLocations.forEach((story) => {
        const marker = L.marker([story.lat, story.lon], {
          icon: customIcon,
        }).addTo(this.map)

        // Enhanced popup with image
        const popupContent = `
          <div class="map-popup-content">
            <img src="${story.photoUrl}" alt="Foto cerita" class="map-popup-image" loading="lazy">
            <div class="map-popup-body">
              <h4 class="map-popup-title">${story.name}</h4>
              <p class="map-popup-description">${story.description}</p>
              <div class="map-popup-meta">
                📅 ${showFormattedDate(story.createdAt, "id-ID")}<br>
                📍 Lat: ${story.lat.toFixed(6)}, Lng: ${story.lon.toFixed(6)}
              </div>
            </div>
          </div>
        `

        marker.bindPopup(popupContent, {
          maxWidth: 300,
          className: "custom-popup",
        })
      })

      if (storyLocations.length > 0) {
        const bounds = storyLocations.map((story) => [story.lat, story.lon])
        this.map.fitBounds(bounds, { padding: [50, 50] })
      }

      setTimeout(() => {
        if (this.map) {
          this.map.invalidateSize()
        }
      }, 300)
    } catch (error) {
      console.error("Error initializing map:", error)
    }
  }

  renderError() {
    this.hideLoading()
    document.getElementById("error-container").classList.remove("hidden")
  }

  setupOfflineDetection() {
    const showOfflineMessage = () => {
      const existingMessage = document.getElementById("offline-message")
      if (existingMessage) return

      const message = document.createElement("div")
      message.id = "offline-message"
      message.className = "offline-banner"
      message.innerHTML = `
        <div class="offline-content">
          <span>📱 Mode Offline</span>
          <p>Beberapa fitur mungkin tidak tersedia</p>
        </div>
      `
      document.body.insertBefore(message, document.body.firstChild)
    }

    const hideOfflineMessage = () => {
      const message = document.getElementById("offline-message")
      if (message) {
        message.remove()
      }
    }

    // Check initial status
    if (!navigator.onLine) {
      showOfflineMessage()
    }

    // Listen for online/offline events
    window.addEventListener("online", () => {
      hideOfflineMessage()
      pushNotificationHelper.showOnline()
    })

    window.addEventListener("offline", () => {
      showOfflineMessage()
      pushNotificationHelper.showOffline()
    })
  }
}
