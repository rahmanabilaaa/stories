export class HomePagePresenter {
  constructor(model, view) {
    this.model = model;
    this.view = view;
  }

  async loadStories() {
    try {
      this.view.showLoading();
      const stories = await this.model.getAllStories();
      this.view.renderStories(stories);
    } catch (error) {
      console.error("Error loading stories:", error);
      this.view.renderError();
    }
  }
}
