export class RegisterPresenter {
  constructor(model, view) {
    this.model = model
    this.view = view
  }

  async register() {
    try {
      this.view.showLoading()
      const registerData = this.view.getFormData()

      if (!registerData.name || !registerData.email || !registerData.password) {
        throw new Error("Semua field harus diisi")
      }

      if (registerData.name.length < 2) {
        throw new Error("Nama minimal 2 karakter")
      }

      if (!this.isValidEmail(registerData.email)) {
        throw new Error("Format email tidak valid")
      }

      if (registerData.password.length < 8) {
        throw new Error("Password minimal 8 karakter")
      }

      console.log("Attempting register...")
      const result = await this.model.register(registerData)

      console.log("Register successful:", result)
      this.view.showRegisterSuccess({ name: registerData.name })
    } catch (error) {
      console.error("Register error:", error)
      this.view.showRegisterError(error.message)
    }
  }

  isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }
}
