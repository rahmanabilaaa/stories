import { AuthModel } from "../../data/models/auth-model.js"
import { RegisterPresenter } from "./register-presenter.js"
import { pushNotificationHelper } from "../../utils/push-notification.js"

export default class RegisterPage {
  constructor() {
    this.authModel = new AuthModel()
  }

  async render() {
    // Redirect if already logged in
    if (this.authModel.isLoggedIn()) {
      window.location.hash = "#/"
      return ""
    }

    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <div class="auth-container">
          <div class="auth-card">
            <header class="auth-header">
              <h1>Daftar Akun Baru</h1>
              <p>Bergabunglah dengan komunitas berbagi cerita!</p>
            </header>

            <form id="register-form" class="auth-form">
              <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input 
                  type="text" 
                  id="name" 
                  name="name" 
                  required 
                  placeholder="Masukkan nama lengkap Anda"
                  autocomplete="name"
                >
              </div>

              <div class="form-group">
                <label for="email">Email</label>
                <input 
                  type="email" 
                  id="email" 
                  name="email" 
                  required 
                  placeholder="Masukkan email Anda"
                  autocomplete="email"
                >
              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input 
                  type="password" 
                  id="password" 
                  name="password" 
                  required 
                  placeholder="Masukkan password (min. 8 karakter)"
                  autocomplete="new-password"
                >
              </div>

              <button type="submit" id="register-button" class="btn btn-primary btn-full">
                <span id="register-text">Daftar</span>
                <div id="register-loading" class="spinner hidden"></div>
              </button>
            </form>

            <div id="register-error" class="error-message hidden">
              <p id="error-text"></p>
            </div>

            <div class="auth-footer">
              <p>Sudah punya akun? <a href="#/login">Masuk di sini</a></p>
            </div>
          </div>
        </div>
      </section>

      <style>
        .auth-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: var(--spacing-lg);
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .auth-card {
          background: var(--surface-color);
          border-radius: var(--radius-xl);
          box-shadow: var(--shadow-xl);
          padding: var(--spacing-3xl);
          width: 100%;
          max-width: 400px;
          border: 1px solid var(--border-color);
        }

        .auth-header {
          text-align: center;
          margin-bottom: var(--spacing-2xl);
        }

        .auth-header h1 {
          font-size: 2rem;
          font-weight: 700;
          margin-bottom: var(--spacing-sm);
          color: var(--text-primary);
        }

        .auth-header p {
          color: var(--text-secondary);
          margin: 0;
        }

        .auth-form {
          margin-bottom: var(--spacing-xl);
        }

        .form-group {
          margin-bottom: var(--spacing-lg);
        }

        .form-group label {
          display: block;
          margin-bottom: var(--spacing-xs);
          font-weight: 600;
          color: var(--text-primary);
        }

        .form-group input {
          width: 100%;
          padding: var(--spacing-md);
          border: 2px solid var(--border-color);
          border-radius: var(--radius);
          font-size: 1rem;
          transition: all 0.3s ease;
          background: var(--surface-color);
          color: var(--text-primary);
        }

        .form-group input:focus {
          outline: none;
          border-color: var(--primary-color);
          box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        .btn-full {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: var(--spacing-sm);
        }

        .auth-footer {
          text-align: center;
          padding-top: var(--spacing-lg);
          border-top: 1px solid var(--border-color);
        }

        .auth-footer p {
          margin: 0;
          color: var(--text-secondary);
        }

        .auth-footer a {
          color: var(--primary-color);
          text-decoration: none;
          font-weight: 600;
        }

        .auth-footer a:hover {
          text-decoration: underline;
        }

        @media (max-width: 768px) {
          .auth-container {
            padding: var(--spacing-md);
          }

          .auth-card {
            padding: var(--spacing-xl);
          }
        }
      </style>
    `
  }

  async afterRender() {
    const presenter = new RegisterPresenter(new AuthModel(), this)

    const form = document.getElementById("register-form")
    if (form) {
      form.addEventListener("submit", async (e) => {
        e.preventDefault()
        await presenter.register()
      })
    }
  }

  getFormData() {
    return {
      name: document.getElementById("name").value.trim(),
      email: document.getElementById("email").value.trim(),
      password: document.getElementById("password").value,
    }
  }

  showLoading() {
    const button = document.getElementById("register-button")
    const text = document.getElementById("register-text")
    const loading = document.getElementById("register-loading")

    button.disabled = true
    text.textContent = "Mendaftar..."
    loading.classList.remove("hidden")
    this.hideError()
  }

  hideLoading() {
    const button = document.getElementById("register-button")
    const text = document.getElementById("register-text")
    const loading = document.getElementById("register-loading")

    button.disabled = false
    text.textContent = "Daftar"
    loading.classList.add("hidden")
  }

  showRegisterSuccess(user) {
    console.log("Register successful, showing notification...")

    // Show notification - PASTI DIPANGGIL
    pushNotificationHelper.showRegister(user.name)

    // Juga tampilkan alert sebagai backup
    alert(`🎉 Registrasi Berhasil!\nSelamat datang ${user.name}! Akun Anda telah dibuat`)

    // Redirect to login
    setTimeout(() => {
      window.location.hash = "#/login"
    }, 1000)
  }

  showRegisterError(message) {
    console.log("Register error, showing notification...")

    this.hideLoading()

    const errorContainer = document.getElementById("register-error")
    const errorText = document.getElementById("error-text")

    errorText.textContent = message
    errorContainer.classList.remove("hidden")

    // Show notification - PASTI DIPANGGIL
    pushNotificationHelper.showError(`Registrasi gagal: ${message}`)

    // Juga tampilkan alert sebagai backup
    alert(`❌ Registrasi gagal: ${message}`)
  }

  hideError() {
    const errorContainer = document.getElementById("register-error")
    errorContainer.classList.add("hidden")
  }
}
