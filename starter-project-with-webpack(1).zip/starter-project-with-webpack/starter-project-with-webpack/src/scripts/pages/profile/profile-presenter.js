export class ProfilePresenter {
  constructor(model, view) {
    this.model = model;
    this.view = view;
  }

  async loadProfile() {
    try {
      this.view.showLoading();
      const profile = await this.model.getProfile();
      this.view.renderProfile(profile);
    } catch (error) {
      console.error("Error loading profile:", error);
      this.view.renderError();
    }
  }
}
