import { UserModel } from "../../data/models/user-model.js";
import { AuthModel } from "../../data/models/auth-model.js";
import { ProfilePresenter } from "./profile-presenter.js";

export default class ProfilePage {
  constructor() {
    this.authModel = new AuthModel();
  }

  async render() {
    if (!this.authModel.isLoggedIn()) {
      window.location.hash = "#/login";
      return "";
    }

    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <header class="page-header">
          <h1>Profil Pengguna</h1>
          <p>Kelola informasi profil Anda</p>
        </header>
        
        <div id="loading-container" class="loading hidden">
          <div class="spinner"></div>
          <p>Memuat profil...</p>
        </div>
        
        <div id="error-container" class="error-message hidden">
          <p>Gagal memuat profil. Silakan coba lagi.</p>
          <button id="retry-button" class="btn btn-secondary">Coba Lagi</button>
        </div>
        
        <div id="profile-container" class="profile-container">
          <!-- Profile content will be rendered here -->
        </div>
      </section>
    `;
  }

  async afterRender() {
    const model = new UserModel();
    const presenter = new ProfilePresenter(model, this);

    const retryButton = document.getElementById("retry-button");
    if (retryButton) {
      retryButton.addEventListener("click", () => {
        presenter.loadProfile();
      });
    }

    await presenter.loadProfile();
  }

  showLoading() {
    document.getElementById("loading-container").classList.remove("hidden");
    document.getElementById("error-container").classList.add("hidden");
    document.getElementById("profile-container").innerHTML = "";
  }

  hideLoading() {
    document.getElementById("loading-container").classList.add("hidden");
  }

  renderProfile(profile) {
    this.hideLoading();
    const container = document.getElementById("profile-container");

    container.innerHTML = `
      <div class="profile-card">
        <div class="profile-info">
          <h2>${profile.name}</h2>
          <p class="profile-email">${profile.email}</p>
          <p class="profile-joined">Bergabung: ${new Date(profile.createdAt).toLocaleDateString("id-ID")}</p>
        </div>
        
        <div class="profile-actions">
          <button id="edit-profile" class="btn btn-primary">Edit Profil</button>
          <button id="logout-button" class="btn btn-secondary">Logout</button>
        </div>
      </div>
    `;

    document.getElementById("logout-button").addEventListener("click", () => {
      this.authModel.logout();
      window.location.hash = "#/";
    });
  }

  renderError() {
    this.hideLoading();
    document.getElementById("error-container").classList.remove("hidden");
  }
}
