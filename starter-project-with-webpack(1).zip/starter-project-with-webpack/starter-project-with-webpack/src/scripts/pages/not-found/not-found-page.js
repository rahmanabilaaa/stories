export default class NotFoundPage {
  async render() {
    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <div class="not-found-container">
          <div class="not-found-content">
            <div class="not-found-icon">
              <span class="error-code">404</span>
              <div class="error-animation">
                <div class="floating-shapes">
                  <div class="shape shape-1"></div>
                  <div class="shape shape-2"></div>
                  <div class="shape shape-3"></div>
                </div>
              </div>
            </div>
            <h1>Halaman Tidak Ditemukan</h1>
            <p>Maaf, halaman yang Anda cari tidak dapat ditemukan. Mungkin halaman tersebut telah dipindahkan, dihapus, atau URL yang Anda masukkan salah.</p>
            
            <div class="suggestions">
              <h3>Mungkin Anda mencari:</h3>
              <ul>
                <li><a href="#/">🏠 Halaman Beranda</a></li>
                <li><a href="#/add-story">✍️ Tambah Cerita Baru</a></li>
                <li><a href="#/favorites">❤️ Cerita Favorit</a></li>
                <li><a href="#/login">🔐 Halaman Login</a></li>
              </ul>
            </div>

            <div class="not-found-actions">
              <a href="#/" class="btn btn-primary">
                <span class="icon">🏠</span>
                Kembali ke Beranda
              </a>
              <button onclick="history.back()" class="btn btn-secondary">
                <span class="icon">↩️</span>
                Kembali
              </button>
              <button onclick="window.location.reload()" class="btn btn-outline">
                <span class="icon">🔄</span>
                Muat Ulang
              </button>
            </div>

            <div class="help-section">
              <details>
                <summary>Butuh bantuan?</summary>
                <div class="help-content">
                  <p>Jika Anda yakin URL yang dimasukkan benar, kemungkinan:</p>
                  <ul>
                    <li>Halaman sedang dalam pemeliharaan</li>
                    <li>Koneksi internet bermasalah</li>
                    <li>Terjadi kesalahan sementara</li>
                  </ul>
                  <p>Coba refresh halaman atau kembali beberapa saat lagi.</p>
                </div>
              </details>
            </div>
          </div>
        </div>
      </section>

      <style>
        .not-found-container {
          display: flex;
          justify-content: center;
          align-items: center;
          min-height: 70vh;
          padding: var(--spacing-2xl) 0;
        }

        .not-found-content {
          text-align: center;
          max-width: 600px;
          padding: var(--spacing-3xl);
          background: var(--surface-color);
          border-radius: var(--radius-xl);
          box-shadow: var(--shadow-xl);
          border: 1px solid var(--border-color);
          position: relative;
          overflow: hidden;
        }

        .not-found-content::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 4px;
          background: linear-gradient(90deg, var(--primary-color), var(--secondary-color), var(--primary-color));
          background-size: 200% 100%;
          animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }

        .not-found-icon {
          margin-bottom: var(--spacing-xl);
          position: relative;
        }

        .error-code {
          font-size: 8rem;
          font-weight: 900;
          color: var(--primary-color);
          line-height: 1;
          display: block;
          text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
          background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: pulse 2s infinite;
        }

        @keyframes pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }

        .error-animation {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 200px;
          height: 200px;
          pointer-events: none;
        }

        .floating-shapes {
          position: relative;
          width: 100%;
          height: 100%;
        }

        .shape {
          position: absolute;
          border-radius: 50%;
          opacity: 0.1;
          animation: float 3s infinite ease-in-out;
        }

        .shape-1 {
          width: 20px;
          height: 20px;
          background: var(--primary-color);
          top: 20%;
          left: 20%;
          animation-delay: 0s;
        }

        .shape-2 {
          width: 15px;
          height: 15px;
          background: var(--secondary-color);
          top: 60%;
          right: 20%;
          animation-delay: 1s;
        }

        .shape-3 {
          width: 25px;
          height: 25px;
          background: var(--success-color);
          bottom: 20%;
          left: 30%;
          animation-delay: 2s;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          33% { transform: translateY(-20px) rotate(120deg); }
          66% { transform: translateY(10px) rotate(240deg); }
        }

        .not-found-content h1 {
          font-size: 2.5rem;
          font-weight: 700;
          margin-bottom: var(--spacing-lg);
          color: var(--text-primary);
          line-height: 1.2;
        }

        .not-found-content > p {
          color: var(--text-secondary);
          margin-bottom: var(--spacing-2xl);
          line-height: 1.6;
          font-size: 1.1rem;
        }

        .suggestions {
          background: var(--background-color);
          border-radius: var(--radius-lg);
          padding: var(--spacing-xl);
          margin-bottom: var(--spacing-2xl);
          border: 1px solid var(--border-color);
        }

        .suggestions h3 {
          font-size: 1.25rem;
          font-weight: 600;
          margin-bottom: var(--spacing-md);
          color: var(--text-primary);
        }

        .suggestions ul {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .suggestions li {
          margin-bottom: var(--spacing-sm);
        }

        .suggestions a {
          display: inline-flex;
          align-items: center;
          gap: var(--spacing-sm);
          color: var(--primary-color);
          text-decoration: none;
          font-weight: 500;
          padding: var(--spacing-sm) var(--spacing-md);
          border-radius: var(--radius);
          transition: all 0.2s;
        }

        .suggestions a:hover {
          background: var(--primary-light);
          transform: translateX(4px);
        }

        .not-found-actions {
          display: flex;
          gap: var(--spacing-md);
          justify-content: center;
          flex-wrap: wrap;
          margin-bottom: var(--spacing-xl);
        }

        .btn .icon {
          font-size: 1.2em;
        }

        .help-section {
          margin-top: var(--spacing-xl);
          text-align: left;
        }

        .help-section details {
          background: var(--background-color);
          border-radius: var(--radius-lg);
          padding: var(--spacing-lg);
          border: 1px solid var(--border-color);
        }

        .help-section summary {
          font-weight: 600;
          color: var(--text-primary);
          cursor: pointer;
          padding: var(--spacing-sm);
          border-radius: var(--radius);
          transition: background-color 0.2s;
        }

        .help-section summary:hover {
          background: var(--surface-hover);
        }

        .help-content {
          margin-top: var(--spacing-md);
          padding-top: var(--spacing-md);
          border-top: 1px solid var(--border-color);
        }

        .help-content p {
          margin-bottom: var(--spacing-md);
          color: var(--text-secondary);
        }

        .help-content ul {
          margin-bottom: var(--spacing-md);
          padding-left: var(--spacing-xl);
        }

        .help-content li {
          margin-bottom: var(--spacing-xs);
          color: var(--text-secondary);
        }

        @media (max-width: 768px) {
          .error-code {
            font-size: 5rem;
          }

          .not-found-content h1 {
            font-size: 2rem;
          }

          .not-found-content {
            padding: var(--spacing-xl);
            margin: var(--spacing-md);
          }

          .not-found-actions {
            flex-direction: column;
          }

          .suggestions {
            text-align: left;
          }
        }

        @media (max-width: 480px) {
          .error-code {
            font-size: 4rem;
          }

          .not-found-content h1 {
            font-size: 1.75rem;
          }

          .not-found-content > p {
            font-size: 1rem;
          }
        }
      </style>
    `
  }

  async afterRender() {
    // Add some interactive effects
    this.addInteractiveEffects()
  }

  addInteractiveEffects() {
    // Add click effect to error code
    const errorCode = document.querySelector(".error-code")
    if (errorCode) {
      errorCode.addEventListener("click", () => {
        errorCode.style.animation = "none"
        setTimeout(() => {
          errorCode.style.animation = "pulse 2s infinite"
        }, 100)
      })
    }

    // Add hover effect to shapes
    const shapes = document.querySelectorAll(".shape")
    shapes.forEach((shape) => {
      shape.addEventListener("mouseenter", () => {
        shape.style.opacity = "0.3"
        shape.style.transform = "scale(1.5)"
      })

      shape.addEventListener("mouseleave", () => {
        shape.style.opacity = "0.1"
        shape.style.transform = "scale(1)"
      })
    })

    // Log 404 for analytics
    console.log("404 Page accessed:", window.location.hash)
  }
}
