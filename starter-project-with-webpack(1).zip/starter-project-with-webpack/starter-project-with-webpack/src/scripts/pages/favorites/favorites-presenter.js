export class FavoritesPresenter {
  constructor(indexedDBHelper, view) {
    this.indexedDBHelper = indexedDBHelper
    this.view = view
  }

  async loadFavorites() {
    try {
      this.view.showLoading()
      const favorites = await this.indexedDBHelper.getAllFavorites()

      // Sort by added date (newest first)
      favorites.sort((a, b) => new Date(b.addedToFavoritesAt) - new Date(a.addedToFavoritesAt))

      this.view.renderFavorites(favorites)
    } catch (error) {
      console.error("Error loading favorites:", error)
      this.view.renderError()
    }
  }
}
