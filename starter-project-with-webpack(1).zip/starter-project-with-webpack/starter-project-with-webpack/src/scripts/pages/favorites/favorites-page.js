import { AuthModel } from "../../data/models/auth-model.js"
import { FavoritesPresenter } from "./favorites-presenter.js"
import { showFormattedDate } from "../../utils/index.js"
import { indexedDBHelper } from "../../utils/indexeddb.js"
import { pushNotificationHelper } from "../../utils/push-notification.js"

export default class FavoritesPage {
  constructor() {
    this.authModel = new AuthModel()
  }

  async render() {
    if (!this.authModel.isLoggedIn()) {
      window.location.hash = "#/login"
      return ""
    }

    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <header class="page-header">
          <h1>❤️ Cerita Favorit</h1>
          <p>Koleksi cerita yang Anda sukai</p>
          <div class="page-actions">
            <a href="#/" class="btn btn-outline">
              <span>🏠</span> Kembali ke Beranda
            </a>
            <button id="clear-all-favorites" class="btn btn-secondary hidden">
              <span>🗑️</span> Hapus Semua Favorit
            </button>
          </div>
        </header>

        <div id="loading-container" class="loading hidden">
          <div class="spinner"></div>
          <p>Memuat cerita favorit...</p>
        </div>

        <div id="error-container" class="error-message hidden">
          <p>Gagal memuat cerita favorit. Silakan coba lagi.</p>
          <button id="retry-button" class="btn btn-secondary">Coba Lagi</button>
        </div>

        <div id="favorites-stats" class="favorites-stats hidden">
          <div class="stats-card">
            <div class="stats-icon">❤️</div>
            <div class="stats-content">
              <h3 id="favorites-count">0</h3>
              <p>Cerita Favorit</p>
            </div>
          </div>
          <div class="stats-card">
            <div class="stats-icon">📅</div>
            <div class="stats-content">
              <h3 id="latest-favorite">-</h3>
              <p>Favorit Terbaru</p>
            </div>
          </div>
        </div>

        <div id="favorites-container" class="stories-grid">
          <!-- Favorite stories will be rendered here -->
        </div>
      </section>

      <style>
        .page-actions {
          display: flex;
          gap: var(--spacing-md);
          justify-content: center;
          flex-wrap: wrap;
          margin-top: var(--spacing-lg);
        }

        .favorites-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: var(--spacing-lg);
          margin: var(--spacing-2xl) 0;
        }

        .stats-card {
          background: var(--surface-color);
          border-radius: var(--radius-lg);
          padding: var(--spacing-xl);
          box-shadow: var(--shadow);
          border: 1px solid var(--border-color);
          display: flex;
          align-items: center;
          gap: var(--spacing-lg);
          transition: all 0.3s ease;
        }

        .stats-card:hover {
          transform: translateY(-2px);
          box-shadow: var(--shadow-lg);
        }

        .stats-icon {
          font-size: 2.5rem;
          opacity: 0.8;
        }

        .stats-content h3 {
          font-size: 2rem;
          font-weight: 700;
          margin: 0 0 var(--spacing-xs) 0;
          color: var(--primary-color);
        }

        .stats-content p {
          margin: 0;
          color: var(--text-secondary);
          font-weight: 500;
        }

        .stories-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: var(--spacing-xl);
          margin-bottom: var(--spacing-3xl);
        }

        .story-card {
          background: var(--surface-color);
          border-radius: var(--radius-lg);
          overflow: hidden;
          box-shadow: var(--shadow);
          transition: all 0.3s ease;
          border: 1px solid var(--border-color);
          position: relative;
        }

        .story-card:hover {
          transform: translateY(-4px);
          box-shadow: var(--shadow-xl);
          border-color: var(--primary-color);
        }

        .story-image {
          width: 100%;
          height: 240px;
          overflow: hidden;
          position: relative;
        }

        .story-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transition: transform 0.3s ease;
        }

        .story-card:hover .story-image img {
          transform: scale(1.05);
        }

        .story-content {
          padding: var(--spacing-xl);
        }

        .story-title {
          font-size: 1.25rem;
          font-weight: 700;
          margin: 0 0 var(--spacing-sm) 0;
          color: var(--text-primary);
          line-height: 1.3;
        }

        .story-description {
          color: var(--text-secondary);
          margin-bottom: var(--spacing-lg);
          line-height: 1.6;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .story-meta {
          display: flex;
          align-items: center;
          gap: var(--spacing-lg);
          font-size: 0.875rem;
          color: var(--text-muted);
          margin-bottom: var(--spacing-sm);
        }

        .story-meta time,
        .story-meta .location {
          display: flex;
          align-items: center;
          gap: var(--spacing-xs);
        }

        .story-meta .location {
          color: var(--success-color);
          font-weight: 500;
        }

        .favorite-badge {
          background: linear-gradient(135deg, #ef4444, #dc2626);
          color: white;
          padding: 4px 12px;
          border-radius: 20px;
          font-size: 0.75rem;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 4px;
          margin-top: var(--spacing-sm);
        }

        .favorite-actions {
          position: absolute;
          top: 12px;
          right: 12px;
          display: flex;
          gap: 8px;
          z-index: 10;
        }

        .delete-btn {
          background: rgba(239, 68, 68, 0.95);
          border: 2px solid transparent;
          border-radius: 50%;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.3s ease;
          box-shadow: 0 2px 12px rgba(239, 68, 68, 0.3);
          color: white;
          font-size: 18px;
          backdrop-filter: blur(8px);
        }

        .delete-btn:hover {
          background: #dc2626;
          transform: scale(1.1);
          box-shadow: 0 4px 20px rgba(239, 68, 68, 0.5);
          border-color: #b91c1c;
        }

        .delete-btn:active {
          transform: scale(0.95);
        }

        .empty-favorites {
          text-align: center;
          padding: var(--spacing-3xl);
          background: var(--surface-color);
          border-radius: var(--radius-xl);
          box-shadow: var(--shadow);
          border: 1px solid var(--border-color);
          grid-column: 1 / -1;
        }

        .empty-favorites-icon {
          font-size: 4rem;
          margin-bottom: var(--spacing-lg);
          opacity: 0.6;
        }

        .empty-favorites h2 {
          font-size: 1.5rem;
          font-weight: 700;
          margin-bottom: var(--spacing-md);
          color: var(--text-primary);
        }

        .empty-favorites p {
          color: var(--text-secondary);
          margin-bottom: var(--spacing-xl);
          font-size: 1rem;
          line-height: 1.6;
        }

        @media (max-width: 768px) {
          .page-actions {
            flex-direction: column;
            align-items: center;
          }

          .stories-grid {
            grid-template-columns: 1fr;
            gap: var(--spacing-lg);
          }

          .favorites-stats {
            grid-template-columns: 1fr;
          }
        }
      </style>
    `
  }

  async afterRender() {
    const presenter = new FavoritesPresenter(indexedDBHelper, this)

    const retryButton = document.getElementById("retry-button")
    if (retryButton) {
      retryButton.addEventListener("click", () => {
        presenter.loadFavorites()
      })
    }

    const clearAllButton = document.getElementById("clear-all-favorites")
    if (clearAllButton) {
      clearAllButton.addEventListener("click", () => {
        this.showClearAllConfirmation()
      })
    }

    await presenter.loadFavorites()
  }

  showLoading() {
    document.getElementById("loading-container").classList.remove("hidden")
    document.getElementById("error-container").classList.add("hidden")
    document.getElementById("favorites-container").innerHTML = ""
    document.getElementById("favorites-stats").classList.add("hidden")
  }

  hideLoading() {
    document.getElementById("loading-container").classList.add("hidden")
  }

  renderFavorites(favorites) {
    this.hideLoading()
    const container = document.getElementById("favorites-container")
    const statsContainer = document.getElementById("favorites-stats")
    const clearAllButton = document.getElementById("clear-all-favorites")

    if (favorites.length === 0) {
      container.innerHTML = `
        <div class="empty-favorites">
          <div class="empty-favorites-icon">💔</div>
          <h2>Belum Ada Cerita Favorit</h2>
          <p>Tambahkan cerita ke favorit dengan menekan tombol ❤️ pada cerita yang Anda sukai di halaman beranda.</p>
          <a href="#/" class="btn btn-primary">
            <span>🏠</span> Jelajahi Cerita
          </a>
        </div>
      `
      statsContainer.classList.add("hidden")
      clearAllButton.classList.add("hidden")
      return
    }

    // Show stats
    this.renderStats(favorites)
    statsContainer.classList.remove("hidden")
    clearAllButton.classList.remove("hidden")

    const favoritesHTML = favorites
      .map(
        (story) => `
      <article class="story-card">
        <div class="favorite-actions">
          <button class="delete-btn" onclick="window.removeFavorite('${story.id}')" 
                  aria-label="Hapus dari favorit" title="Hapus dari favorit">
            🗑️
          </button>
        </div>
        <div class="story-image">
          <img src="${story.photoUrl}" alt="Foto cerita: ${story.description}" loading="lazy">
        </div>
        <div class="story-content">
          <h3 class="story-title">${story.name}</h3>
          <p class="story-description">${story.description}</p>
          <div class="story-meta">
            <time datetime="${story.createdAt}">
              📅 ${showFormattedDate(story.createdAt, "id-ID")}
            </time>
            ${story.lat && story.lon ? `<span class="location">📍 Ada lokasi</span>` : ""}
          </div>
          <div class="favorite-badge">
            ❤️ Ditambahkan: ${showFormattedDate(story.addedToFavoritesAt, "id-ID")}
          </div>
        </div>
      </article>
    `,
      )
      .join("")

    container.innerHTML = favoritesHTML

    // Setup global remove function
    window.removeFavorite = async (storyId) => {
      const story = favorites.find((f) => f.id === storyId)
      this.showDeleteConfirmation(storyId, story?.description || "cerita ini")
    }
  }

  renderStats(favorites) {
    const countElement = document.getElementById("favorites-count")
    const latestElement = document.getElementById("latest-favorite")

    countElement.textContent = favorites.length

    if (favorites.length > 0) {
      const latest = favorites.reduce((latest, current) => {
        return new Date(current.addedToFavoritesAt) > new Date(latest.addedToFavoritesAt) ? current : latest
      })
      latestElement.textContent = showFormattedDate(latest.addedToFavoritesAt, "id-ID")
    } else {
      latestElement.textContent = "-"
    }
  }

  showDeleteConfirmation(storyId, description) {
    if (confirm(`Yakin ingin menghapus "${description.substring(0, 50)}..." dari favorit?`)) {
      this.deleteFavorite(storyId, description)
    }
  }

  async deleteFavorite(storyId, description) {
    console.log("Deleting favorite:", storyId)
    const success = await indexedDBHelper.removeFromFavorites(storyId)
    if (success) {
      console.log("Favorite deleted, showing notification...")

      // Show notification - PASTI DIPANGGIL
      pushNotificationHelper.showFavoriteRemoved(description)

      // Juga tampilkan alert sebagai backup
      alert("🗑️ Dihapus dari favorit!")

      const presenter = new FavoritesPresenter(indexedDBHelper, this)
      await presenter.loadFavorites()
    } else {
      pushNotificationHelper.showError("Gagal menghapus cerita dari favorit")
      alert("❌ Gagal menghapus cerita dari favorit")
    }
  }

  showClearAllConfirmation() {
    if (confirm("Yakin ingin menghapus SEMUA cerita dari favorit? Tindakan ini tidak dapat dibatalkan.")) {
      this.clearAllFavorites()
    }
  }

  async clearAllFavorites() {
    try {
      const favorites = await indexedDBHelper.getAllFavorites()
      console.log("Clearing all favorites:", favorites.length)

      for (const favorite of favorites) {
        await indexedDBHelper.removeFromFavorites(favorite.id)
      }

      console.log("All favorites cleared, showing notification...")

      // Show notification - PASTI DIPANGGIL
      pushNotificationHelper.show("🗑️ Semua Favorit Dihapus", `${favorites.length} cerita telah dihapus dari favorit`)

      // Juga tampilkan alert sebagai backup
      alert(`🗑️ Semua Favorit Dihapus\n${favorites.length} cerita telah dihapus dari favorit`)

      const presenter = new FavoritesPresenter(indexedDBHelper, this)
      await presenter.loadFavorites()
    } catch (error) {
      console.error("Error clearing all favorites:", error)
      pushNotificationHelper.showError("Gagal menghapus semua favorit")
      alert("❌ Gagal menghapus semua favorit")
    }
  }

  renderError() {
    this.hideLoading()
    document.getElementById("error-container").classList.remove("hidden")
  }
}
