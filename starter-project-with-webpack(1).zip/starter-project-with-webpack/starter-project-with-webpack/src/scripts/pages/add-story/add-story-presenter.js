import { pushNotificationHelper } from "../../utils/push-notification.js"

export class AddStoryPresenter {
  constructor(model, view) {
    this.model = model
    this.view = view
  }

  getNotificationSettings() {
    const defaultSettings = {
      pushNotifications: true,
      storyNotifications: true,
      favoriteNotifications: true,
    }

    try {
      const saved = localStorage.getItem("notificationSettings")
      return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings
    } catch {
      return defaultSettings
    }
  }

  async showNotification(title, options = {}) {
    console.log(`[AddStoryPresenter] Attempting to show notification: "${title}"`)

    const settings = this.getNotificationSettings()
    console.log("[AddStoryPresenter] Current settings:", settings)

    // Always try to show notification, but log if disabled
    if (!settings.storyNotifications) {
      console.log("[AddStoryPresenter] Story notifications disabled, but showing anyway for testing")
    }

    try {
      const result = await pushNotificationHelper.showLocalNotification(title, {
        icon: "/icons/icon-192x192.png",
        badge: "/icons/icon-72x72.png",
        requireInteraction: true,
        ...options,
      })

      console.log(`[AddStoryPresenter] Notification result:`, result)
      return result
    } catch (error) {
      console.error("[AddStoryPresenter] Notification error:", error)
      return false
    }
  }

  async submitStory() {
    try {
      this.view.showLoading()
      const storyData = this.view.getFormData()

      if (!storyData.description || !storyData.photo) {
        throw new Error("Data tidak lengkap")
      }

      if (storyData.description.length < 10) {
        throw new Error("Deskripsi minimal 10 karakter")
      }

      console.log("Creating story...")
      await this.model.createStory(storyData)

      console.log("Story created successfully, showing notification...")
      // Show success notification - PASTI DIPANGGIL
      pushNotificationHelper.showStoryCreated(storyData.description)

      // Juga tampilkan alert sebagai backup
      alert("🎉 Cerita berhasil dibuat!")

      this.view.showSuccess()
    } catch (error) {
      console.error("Error submitting story:", error)

      // Show error notification
      pushNotificationHelper.showError(`Gagal membuat story: ${error.message}`)

      // Juga tampilkan alert sebagai backup
      alert(`❌ Gagal membuat story: ${error.message}`)

      this.view.showSubmitError(error.message)
    }
  }
}
