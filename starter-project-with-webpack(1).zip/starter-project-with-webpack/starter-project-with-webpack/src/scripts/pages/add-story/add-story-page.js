import { AuthModel } from "../../data/models/auth-model.js"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

export default class AddStoryPage {
  constructor() {
    this.authModel = new AuthModel()
    this.currentStream = null
    this.selectedLocation = null
    this.maxFileSize = 2 * 1024 * 1024
    this.targetFileSize = 500 * 1024
    this.locationMap = null
    this.locationMarker = null
  }

  createLocationIcon() {
    return L.divIcon({
      className: "custom-location-marker",
      html: `
        <div class="location-marker-pin">
          <div class="location-marker-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" fill="#3498db"/>
            </svg>
          </div>
        </div>
      `,
      iconSize: [35, 45],
      iconAnchor: [17.5, 45],
      popupAnchor: [0, -45],
    })
  }

  async render() {
    if (!this.authModel.isLoggedIn()) {
      window.location.hash = "#/login"
      return ""
    }

    return `
      <div class="skip-link">
        <a href="#main-content">Skip to content</a>
      </div>
      <section class="container">
        <header class="page-header">
          <h1>📝 Tambah Cerita Baru</h1>
          <p>Bagikan momen berharga Anda dengan dunia</p>
        </header>

        <form id="add-story-form" class="story-form" novalidate>
          <div class="form-group">
            <label for="description">Deskripsi Cerita *</label>
            <textarea id="description" name="description" required 
              placeholder="Ceritakan momen berharga Anda... (minimal 10 karakter)" 
              rows="4" maxlength="500"></textarea>
            <div class="form-help">
              <span id="char-count">0/500 karakter</span>
            </div>
            <div class="error-message" id="description-error"></div>
          </div>

          <div class="form-group">
            <label for="photo">Foto Cerita *</label>
            <div class="file-size-info">
              <small>Maksimal ukuran file: 2MB. File akan dikompres otomatis untuk performa optimal.</small>
            </div>
            <div class="photo-input-container">
              <div id="camera-container" class="camera-container">
                <video id="camera-preview" class="camera-preview hidden" autoplay playsinline></video>
                <canvas id="photo-canvas" class="photo-canvas hidden"></canvas>
                <div id="photo-preview" class="photo-preview hidden">
                  <div class="image-container">
                    <img id="preview-image" alt="Preview foto yang akan diupload">
                  </div>
                  <div class="photo-info">
                    <span id="file-size-display"></span>
                  </div>
                </div>
              </div>
              <div class="camera-controls">
                <button type="button" id="start-camera" class="btn btn-secondary">
                  📷 Buka Kamera
                </button>
                <button type="button" id="capture-photo" class="btn btn-primary hidden">
                  📸 Ambil Foto
                </button>
                <button type="button" id="retake-photo" class="btn btn-secondary hidden">
                  🔄 Ambil Ulang
                </button>
                <input type="file" id="file-input" accept="image/*" class="file-input">
                <label for="file-input" class="btn btn-outline">
                  📁 Pilih File
                </label>
              </div>
            </div>
            <div class="error-message" id="photo-error"></div>
          </div>

          <div class="form-group">
            <label for="location-toggle">Lokasi Cerita</label>
            <div class="location-container">
              <label class="toggle-switch">
                <input type="checkbox" id="location-toggle" checked>
                <span class="slider"></span>
              </label>
              <span>Sertakan lokasi dalam cerita Anda</span>
            </div>
            <div id="location-section" class="location-section">
              <div class="location-header">
                <h3>📍 Pilih Lokasi Cerita</h3>
                <p>Klik pada peta untuk menandai lokasi cerita Anda</p>
              </div>
              <div id="location-map" class="location-map"></div>
              <div class="location-info">
                <div id="selected-location" class="selected-location">
                  <i>Klik pada peta untuk memilih lokasi</i>
                </div>
              </div>
            </div>
          </div>

          <div class="form-actions">
            <button type="button" id="cancel-button" class="btn btn-secondary">
              ❌ Batal
            </button>
            <button type="submit" id="submit-button" class="btn btn-primary" disabled>
              <span class="button-text">🚀 Bagikan Cerita</span>
              <span class="loading-spinner hidden"></span>
            </button>
          </div>
        </form>
      </section>

      <style>
        .story-form {
          max-width: 800px;
          margin: 0 auto;
          background: var(--surface-color);
          padding: var(--spacing-2xl);
          border-radius: var(--radius-xl);
          box-shadow: var(--shadow-lg);
          border: 1px solid var(--border-color);
        }

        .form-help {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-top: var(--spacing-xs);
        }

        #char-count {
          font-size: 0.75rem;
          color: var(--text-muted);
          font-weight: 500;
        }

        #char-count.warning {
          color: var(--warning-color);
        }

        #char-count.error {
          color: var(--error-color);
        }

        .file-size-info {
          margin-bottom: var(--spacing-sm);
        }
        
        .file-size-info small {
          color: var(--text-secondary);
          font-size: 0.875rem;
        }
        
        .photo-preview {
          width: 100%;
          max-width: 100%;
          border-radius: var(--radius-lg);
          overflow: hidden;
          background-color: var(--background-color);
          border: 1px solid var(--border-color);
        }
        
        .image-container {
          width: 100%;
          height: 300px;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          background-color: #000;
        }
        
        .image-container img {
          width: 100%;
          height: 100%;
        }
      </style>
    `
  }

  async afterRender() {
    // Initialize form elements
    this.#initializeForm()
    this.#initializeCamera()
    this.#initializeLocation()
    this.#setupEventListeners()
  }

  #initializeForm() {
    const form = document.getElementById("add-story-form")
    const descriptionTextarea = document.getElementById("description")
    const charCount = document.getElementById("char-count")
    const submitButton = document.getElementById("submit-button")

    if (descriptionTextarea && charCount) {
      descriptionTextarea.addEventListener("input", () => {
        const length = descriptionTextarea.value.length
        charCount.textContent = `${length}/500 karakter`

        if (length > 450) {
          charCount.classList.add("error")
        } else if (length > 400) {
          charCount.classList.add("warning")
        } else {
          charCount.classList.remove("warning", "error")
        }

        this.#validateForm()
      })
    }
  }

  #initializeCamera() {
    const startCameraBtn = document.getElementById("start-camera")
    const captureBtn = document.getElementById("capture-photo")
    const retakeBtn = document.getElementById("retake-photo")
    const fileInput = document.getElementById("file-input")

    if (startCameraBtn) {
      startCameraBtn.addEventListener("click", () => this.#startCamera())
    }

    if (captureBtn) {
      captureBtn.addEventListener("click", () => this.#capturePhoto())
    }

    if (retakeBtn) {
      retakeBtn.addEventListener("click", () => this.#retakePhoto())
    }

    if (fileInput) {
      fileInput.addEventListener("change", (e) => this.#handleFileSelect(e))
    }
  }

  #initializeLocation() {
    const locationToggle = document.getElementById("location-toggle")
    const locationSection = document.getElementById("location-section")

    if (locationToggle && locationSection) {
      locationToggle.addEventListener("change", () => {
        if (locationToggle.checked) {
          locationSection.style.display = "block"
          this.#initializeMap()
        } else {
          locationSection.style.display = "none"
          this.selectedLocation = null
        }
      })

      // Initialize map if toggle is checked
      if (locationToggle.checked) {
        this.#initializeMap()
      }
    }
  }

  #setupEventListeners() {
    const cancelBtn = document.getElementById("cancel-button")

    if (cancelBtn) {
      cancelBtn.addEventListener("click", () => {
        if (confirm("Yakin ingin membatalkan? Data yang sudah diisi akan hilang.")) {
          window.location.hash = "#/"
        }
      })
    }
  }

  #validateForm() {
    const description = document.getElementById("description")?.value || ""
    const photoPreview = document.getElementById("photo-preview")
    const submitButton = document.getElementById("submit-button")

    const isValid = description.length >= 10 && !photoPreview?.classList.contains("hidden")

    if (submitButton) {
      submitButton.disabled = !isValid
    }
  }

  #startCamera() {
    // Camera implementation
    console.log("Starting camera...")
  }

  #capturePhoto() {
    // Capture implementation
    console.log("Capturing photo...")
  }

  #retakePhoto() {
    // Retake implementation
    console.log("Retaking photo...")
  }

  #handleFileSelect(event) {
    // File select implementation
    console.log("File selected:", event.target.files[0])
  }

  #initializeMap() {
    // Map initialization
    console.log("Initializing map...")
  }
}
