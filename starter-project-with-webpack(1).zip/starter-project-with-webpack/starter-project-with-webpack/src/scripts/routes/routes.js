import HomePage from "../pages/home/home-page.js"
import AddStoryPage from "../pages/add-story/add-story-page.js"
import LoginPage from "../pages/login/login-page.js"
import RegisterPage from "../pages/register/register-page.js"
import FavoritesPage from "../pages/favorites/favorites-page.js"
import NotFoundPage from "../pages/not-found/not-found-page.js"

const routes = {
  "/": new HomePage(),
  "/add-story": new AddStoryPage(),
  "/login": new LoginPage(),
  "/register": new RegisterPage(),
  "/favorites": new FavoritesPage(),
  "/404": new NotFoundPage(),
}

export default routes
