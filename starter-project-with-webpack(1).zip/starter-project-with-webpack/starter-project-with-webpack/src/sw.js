const CACHE_NAME = "berbagi-cerita-v1"
const STATIC_CACHE_NAME = "berbagi-cerita-static-v1"
const DYNAMIC_CACHE_NAME = "berbagi-cerita-dynamic-v1"
const IMAGE_CACHE_NAME = "berbagi-cerita-images-v1"

const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/styles/styles.css",
  "/manifest.json",
  "/icons/icon-72x72.png",
  "/icons/icon-96x96.png",
  "/icons/icon-128x128.png",
  "/icons/icon-144x144.png",
  "/icons/icon-152x152.png",
  "/icons/icon-192x192.png",
  "/icons/icon-384x384.png",
  "/icons/icon-512x512.png",
  "/favicon.png",
]

// Install event
self.addEventListener("install", (event) => {
  console.log("🔧 Service Worker: Installing...")
  event.waitUntil(
    caches
      .open(STATIC_CACHE_NAME)
      .then((cache) => {
        console.log("📦 Service Worker: Caching static assets")
        return cache.addAll(STATIC_ASSETS)
      })
      .then(() => {
        console.log("✅ Service Worker: Installation complete")
        return self.skipWaiting()
      })
      .catch((error) => {
        console.error("❌ Service Worker: Installation failed", error)
      }),
  )
})

// Activate event
self.addEventListener("activate", (event) => {
  console.log("🚀 Service Worker: Activating...")
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== STATIC_CACHE_NAME && cacheName !== DYNAMIC_CACHE_NAME && cacheName !== IMAGE_CACHE_NAME) {
              console.log("🗑️ Service Worker: Deleting old cache:", cacheName)
              return caches.delete(cacheName)
            }
          }),
        )
      })
      .then(() => {
        console.log("✅ Service Worker: Activation complete")
        return self.clients.claim()
      }),
  )
})

// Fetch event
self.addEventListener("fetch", (event) => {
  const { request } = event

  // Skip non-GET requests
  if (request.method !== "GET") {
    return
  }

  // Handle API requests
  if (request.url.includes("story-api.dicoding.dev")) {
    event.respondWith(
      caches.open(DYNAMIC_CACHE_NAME).then((cache) => {
        return fetch(request)
          .then((response) => {
            if (response.status === 200) {
              cache.put(request, response.clone())
            }
            return response
          })
          .catch(() => {
            return cache.match(request).then((cachedResponse) => {
              if (cachedResponse) {
                return cachedResponse
              }
              return new Response(
                JSON.stringify({
                  error: true,
                  message: "Offline - data not available",
                  offline: true,
                }),
                {
                  status: 503,
                  headers: { "Content-Type": "application/json" },
                },
              )
            })
          })
      }),
    )
    return
  }

  // Handle other requests
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse
      }

      return fetch(request)
        .then((response) => {
          if (!response || response.status !== 200 || response.type !== "basic") {
            return response
          }

          const responseToCache = response.clone()
          caches.open(DYNAMIC_CACHE_NAME).then((cache) => {
            cache.put(request, responseToCache)
          })

          return response
        })
        .catch(() => {
          if (request.destination === "document") {
            return caches.match("/")
          }
          return new Response("Offline - Resource not available", {
            status: 503,
            statusText: "Service Unavailable",
          })
        })
    }),
  )
})

// Message event - PENTING untuk menerima perintah notifikasi
self.addEventListener("message", (event) => {
  console.log("📨 Service Worker: Message received:", event.data)

  if (event.data && event.data.type === "SHOW_NOTIFICATION") {
    const { title, options } = event.data

    console.log("🔔 Service Worker: Showing notification:", title)

    const notificationOptions = {
      body: options.body || "",
      icon: options.icon || "/icons/icon-192x192.png",
      badge: options.badge || "/icons/icon-72x72.png",
      tag: options.tag || "app-notification",
      vibrate: [200, 100, 200],
      data: {
        timestamp: Date.now(),
        url: options.url || "/",
      },
      actions: [
        {
          action: "open",
          title: "Buka App",
        },
      ],
      requireInteraction: false,
      silent: false,
      ...options,
    }

    self.registration
      .showNotification(title, notificationOptions)
      .then(() => {
        console.log("✅ Service Worker: Notification shown successfully")
      })
      .catch((error) => {
        console.error("❌ Service Worker: Error showing notification:", error)
      })
  }

  // Handle connection status
  if (event.data && event.data.type === "CONNECTION_STATUS") {
    console.log("🌐 Connection status:", event.data.online ? "online" : "offline")
  }
})

// Push event untuk notifikasi dari server
self.addEventListener("push", (event) => {
  console.log("📥 Service Worker: Push event received")

  let notificationData = {
    title: "Berbagi Cerita",
    body: "Ada update baru!",
    icon: "/icons/icon-192x192.png",
    badge: "/icons/icon-72x72.png",
    tag: "push-notification",
    requireInteraction: false,
    vibrate: [200, 100, 200],
    data: {
      timestamp: Date.now(),
      url: "/",
    },
    actions: [
      {
        action: "open",
        title: "Buka App",
      },
      {
        action: "close",
        title: "Tutup",
      },
    ],
  }

  if (event.data) {
    try {
      const data = event.data.json()
      notificationData = { ...notificationData, ...data }
    } catch (error) {
      console.error("❌ Error parsing push data:", error)
      notificationData.body = event.data.text() || notificationData.body
    }
  }

  event.waitUntil(
    self.registration
      .showNotification(notificationData.title, notificationData)
      .then(() => {
        console.log("✅ Push notification shown")
      })
      .catch((error) => {
        console.error("❌ Error showing push notification:", error)
      }),
  )
})

// Notification click event
self.addEventListener("notificationclick", (event) => {
  console.log("👆 Service Worker: Notification clicked")

  event.notification.close()

  if (event.action === "open" || !event.action) {
    // Buka atau fokus ke aplikasi
    event.waitUntil(
      clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
        // Cari tab yang sudah terbuka
        for (const client of clientList) {
          if (client.url.includes(self.location.origin) && "focus" in client) {
            console.log("🎯 Focusing existing tab")
            return client.focus()
          }
        }

        // Jika tidak ada tab yang terbuka, buka yang baru
        if (clients.openWindow) {
          const urlToOpen = event.notification.data?.url || "/"
          console.log("🆕 Opening new tab:", urlToOpen)
          return clients.openWindow(urlToOpen)
        }
      }),
    )
  }
})

// Notification close event
self.addEventListener("notificationclose", (event) => {
  console.log("❌ Service Worker: Notification closed")
})

// Background sync event
self.addEventListener("sync", (event) => {
  console.log("🔄 Service Worker: Background sync triggered:", event.tag)

  if (event.tag === "background-sync") {
    event.waitUntil(
      // Handle background sync tasks
      Promise.resolve().then(() => {
        console.log("✅ Background sync completed")
      }),
    )
  }
})

console.log("🚀 Service Worker loaded and ready!")
